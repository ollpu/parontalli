<!--Kotisivut Riikka/Hevoset, draft 1; /piensivu/p_princess_nova_videot.html-->

<html>
<head>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-51951207-1', 'parontalli.fi');
  ga('require', 'displayfeatures');
  ga('send', 'pageview');
</script>

<meta charset="UTF-8">
<meta name="msvalidate.01" content="0FB9B019DA55297EDC00A30165EA3E85" />

<title>
	Videoita: Paron Princess Nova
</title>

	<link href='http://fonts.googleapis.com/css?family=Raleway' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Berkshire+Swash' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" class="text/css" href="../main.css">

</head>


<body>
<div class="bg1"></div>
<div class="bg2"></div>
<br/>
<div class="header">
	<h1>Parontalli</h1><br/>
</div>

<div class="nav">
		<a class="punainen" href="../?s=9369#otsikko7" id="">
		&nbsp;Takaisin&nbsp;
		</a>
		&nbsp;&nbsp;
		<a class="s_sininen" href="" id="thispage">
		&nbsp;Videoita: Paron Princess Nova&nbsp;
		</a>
		&nbsp;&nbsp;
	<hr class="header" id="">
</div>
<div class="content"><br>
	<h2>Käynti</h2><br>
	<iframe class="video" src='http://www.youtube.com/embed/w9Ke-CNVev0' allowfullscreen></iframe><br>
	<h2>Ravi</h2><br>
	<iframe class="video" src='http://www.youtube.com/embed/qK2ZZRF9og4' allowfullscreen></iframe><iframe class="video" src='http://www.youtube.com/embed/stPeqGY8kag' allowfullscreen></iframe><br>
	<h2>Laukka</h2><br>
	<iframe class="video" src='http://www.youtube.com/embed/_bs6TrBe8ss' allowfullscreen></iframe><iframe class="video" src='http://www.youtube.com/embed/uvDiutvw-Dg' allowfullscreen></iframe><br>
</div>
<br><br><br><br><br><br><br><br>
<div class="footer">
<hr>
<a href="./ohjaus">Hallinta</a> - Sivun rakenteen tehnyt: <a href="mailto:rpsalmi@gmail.com">Roope Salmi</a>
</div>
</body>
<html>
