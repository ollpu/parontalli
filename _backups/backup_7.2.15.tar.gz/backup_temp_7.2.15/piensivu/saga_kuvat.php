<!--Kotisivut Riikka/Hevoset, draft 1; /piensivu/saga_kuvat.php-->

<html>
<head>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-51951207-1', 'parontalli.fi');
  ga('require', 'displayfeatures');
  ga('send', 'pageview');
</script>

<meta charset="UTF-8">
<meta name="msvalidate.01" content="0FB9B019DA55297EDC00A30165EA3E85" />

<title>
	Kuvia: Saga
</title>

	<link href='http://fonts.googleapis.com/css?family=Raleway' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Berkshire+Swash' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" class="text/css" href="../main.css">

</head>


<body>
<div class="bg1"></div>
<div class="bg2"></div>
<br/>
<div class="header">
	<h1>Parontalli</h1><br/>
</div>

<div class="nav">
		<a class="punainen" href="../?s=5db6#otsikko1" id="">
		&nbsp;Takaisin&nbsp;
		</a>
		&nbsp;&nbsp;
		<a class="s_sininen" href="" id="thispage">
		&nbsp;Kuvia: Saga&nbsp;
		</a>
		&nbsp;&nbsp;
	<hr class="header" id="">
</div>
<div class="content"><br>
	<h2>Kouluratsastuskuvia</h2><br>
	<div class="img2"><img class="content" src="http://s25.postimg.org/e25991kzz/Kouluratsastus1.jpg"> <img class="content" src="http://s25.postimg.org/q2qp9rsen/Kouluratsastus2.jpg"></div><br>
	
	<h2>Maastoestekuvia</h2><br>
	<div class="img3"><img class="content" src="http://s25.postimg.org/tvet38xan/Maastoeste_R1_I3.jpg"> <img class="content" src="http://s25.postimg.org/jk2gal5lb/Maastoeste_R1_I1.jpg"> <img class="content" src="http://s25.postimg.org/tjxcqhgun/Maastoeste_R2_I3.jpg"></div><br>
	<div class="img3"><img class="content" src="http://s25.postimg.org/nzkvfuhzj/Maastoeste_R1_I2.jpg"> <img class="content" src="http://s25.postimg.org/vea7883v3/Maastoeste_R2_I1.jpg"> <img class="content" src="http://s25.postimg.org/nk9lmtw27/Maastoeste_R2_I2.jpg"></div><br>
	<div class="img3"><img class="content" src="http://s25.postimg.org/4lk1g5qj3/Maastoeste_R3_I1.jpg"> <img class="content" src="http://s25.postimg.org/mykmqq0zz/Maastoeste_R3_I2.jpg"> <img class="content" src="http://s25.postimg.org/mabs7s2a7/Maastoeste_R3_I3.jpg"></div><br>
</div>
<br><br><br><br><br><br><br><br>
<div class="footer">
<hr>
<a href="./ohjaus">Hallinta</a> - Sivun rakenteen tehnyt: <a href="mailto:rpsalmi@gmail.com">Roope Salmi</a>
</div>
</body>
<html>
